import json
import sys

with open(sys.argv[3]) as handle:
    fault = json.load(handle)['fault']
assert fault in {'drop', 'bad_probabilities', 'swapped_labels'}
with open(sys.argv[1]) as source, open(sys.argv[2], 'w') as output:
    for index, line in enumerate(source):
        row = json.loads(line)
        if fault == 'drop' and index == 0:
            continue
        label = row['judgement']
        probabilities = [1, 0] if label == 'negative' else [0, 1]
        if fault == 'bad_probabilities':
            probabilities = [1, 1]
        elif fault == 'swapped_labels':
            probabilities.reverse()
        row['decision'] = {
            'state': json.dumps({'left': row['left'], 'right': row['right']}),
            'question': 'Which supplied matching judgement applies?',
            'kind': 'choice',
            'options': ['negative', 'positive'],
            'target_probabilities': probabilities,
            'target_semantics': 'categorical_gold',
        }
        output.write(json.dumps(row) + '\n')
